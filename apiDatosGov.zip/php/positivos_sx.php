<?php

include_once('header.php')

?>

 

<div class="modal-body row"> 
 <div class="col-md-6"> 
 
 <canvas id="pie-chart" width=100%  ></canvas>
 </div> 
 <div class="col-md-6 mt-4"> 
 <div id="listarPosex"  ></div>
 </div> 
</div> 


   


<?php
include_once('footer.php')
?>

    

<script>window.onload = listarPositivosSx();</script>

